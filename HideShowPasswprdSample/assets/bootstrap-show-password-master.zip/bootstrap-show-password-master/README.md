Bootstrap Show Password
=======================

Show/hide password plugin for twitter bootstrap.

To get started, check out:

* [Docs](http://bootstrap-show-password.wenzhixin.net.cn)
* [Examples](http://bootstrap-show-password.wenzhixin.net.cn/examples)

## Reporting issues

Please provide jsFiddle when creating issues!

It's really saves much time. Use this as template:

[jsFiddle Bootstrap Show Password](http://jsfiddle.net/wenyi/L1ugpqk5/1/)

Your feedback is very appreciated!

## Release History

Look at the [Change Log](https://github.com/wenzhixin/bootstrap-show-password/blob/master/CHANGELOG.md)

## LICENSE

[The MIT License](https://github.com/wenzhixin/bootstrap-show-password/blob/master/LICENSE)
