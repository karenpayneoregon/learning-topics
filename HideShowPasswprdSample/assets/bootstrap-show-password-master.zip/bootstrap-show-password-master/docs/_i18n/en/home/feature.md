### Features

* Show/Hide password for a normal input element
* Support all bootstrap version
* Set placement of icon
* Custom icons
* Options can be passed via data attributes or JavaScript
