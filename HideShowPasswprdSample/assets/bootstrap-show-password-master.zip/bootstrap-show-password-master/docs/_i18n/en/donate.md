Bootstrap Show Password is a free plug-in which be made in my spare time.

If your project get the help from Bootstrap Show Password, you can donate to Bootstrap Show Password.

With your help, I believe that I will continue to strive to let Bootstrap Show Password be better.
